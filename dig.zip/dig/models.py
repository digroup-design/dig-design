#from django.db import models
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dig.settings')

#All previously defined models have been deprecated. See database.py